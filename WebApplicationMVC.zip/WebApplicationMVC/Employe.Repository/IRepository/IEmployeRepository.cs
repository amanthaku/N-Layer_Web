﻿using DataAcessVM.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Employe.Repository.IRepository
{
    public interface IEmployeRepository
    {
        public Task<List<EmployeModel>> EmployeList();

        public Task<bool> AddEmployeeData(EmployeModel model);


        public Task<bool> DeleteEmployee(string id);

        public Task<EmployeModel> GetUserById(string id);

        public Task<bool> UpdateEmployee(EmployeModel model);
        public Task<bool> Login(string Email, string password);

    }
}

































//Task<List<EmployeModel>> GetAllAsync();
//Task<EmployeModel> GetByIdAsync(int id);
//Task<bool> AddAsync(EmployeModel model);
//Task<bool> UpdateAsync(EmployeModel model);
//Task<bool> DeleteAsync(int id);