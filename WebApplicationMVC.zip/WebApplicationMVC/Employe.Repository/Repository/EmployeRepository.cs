﻿//using ApplicationLayer.IServices;
using DataAcessLayer;
using DataAcessLayer.Models;
using DataAcessVM.ViewModel;
using Employe.Repository.IRepository;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Employe.Repository.Repository.EmployeRepository;

namespace Employe.Repository.Repository
{

    public class EmployeRepository : IEmployeRepository
    {
        

        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        public EmployeRepository(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        public async Task<List<EmployeModel>> EmployeList()
        {
            var users = await _userManager.Users.ToListAsync();
            var listData = users.Select(u => new EmployeModel
            {
                Id = u.Id,
                Name = u.Name,
                Salary = u.Salary,
                city = u.city,
                State = u.State,
                Email = u.Email,
                Phone = u.PhoneNumber,

            }).ToList();
            return listData;
        }

        public async Task<bool> AddEmployeeData(EmployeModel model)
        {
            var userExists = await _userManager.FindByEmailAsync(model.Email);
            if (userExists != null)
            {

                return false;
            }
            var user = new ApplicationUser()
            {

                UserName = model.Email,
                Name = model.Name,
                Salary = model.Salary,
                city = model.city,
                State = model.State,
                Email = model.Email,
                PhoneNumber = model.Phone,

            };
            var result = await _userManager.CreateAsync(user, model.Password);
            if (!result.Succeeded)
            {
                return false;
            }
            return true;
        }

        public async Task<bool> DeleteEmployee(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
                return false;
            var result = await _userManager.DeleteAsync(user);
            return result.Succeeded;
        }

        public async Task<EmployeModel> GetUserById(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
                return null;
            var model = new EmployeModel
            {
                //    EmpID = user.Id,
                Name = user.Name,
                Salary = user.Salary,
                city = user.city,
                State = user.State,
                Email = user.Email,
                Phone = user.PhoneNumber,

            };
            return model;
        }

        public async Task<bool> UpdateEmployee(EmployeModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null)
                return false;
            user.Name = model.Name;
            user.Salary = model.Salary;
            user.city = model.city;
            user.State = model.State;
            user.Email = model.Email;
            user.PhoneNumber = model.Phone;
            var result = await _userManager.UpdateAsync(user);
            return result.Succeeded;
        }
        public async Task<bool> Login(string Email, string password)
        {
            var result = await _signInManager.PasswordSignInAsync(Email, password, false, lockoutOnFailure: false);
            return result.Succeeded;
        }

    }
}

