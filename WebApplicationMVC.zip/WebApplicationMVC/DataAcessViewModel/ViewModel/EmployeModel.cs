﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcessVM.ViewModel
{
    public class EmployeModel
    {


        [Required]
        public string Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string State { get; set; }

        [Required]
        public string city { get; set; }
        [Required]
        public string Salary { get; set; }
        [Required]

        public string Email { get; set; }
        [Required]

        public string Phone { get; set; }

        [Required]
        public string? Password { get; set; }
       

    }
}










//public string path { get; set; }
//[NotMapped]
//[Display(Name = "Choose image ")]
//public IFormFile ImagePath { get; set; }