﻿$(document).ready(function () {

    ShowEmployeeData();
    
});


function ShowEmployeeData() {
   
    $.ajax({
        url: "/Employe/Read",
        type: 'Get',
        dataType: 'json',
        contentType: 'application/json;charset=utf-8;',
        success: function (result, statu, xhr) {
            console.log(result)
            console.log(result[0])
            console.log(result[0].id)
            console.log(typeof result[0].id)
            var object = '';
             
            $.each(result, function (index, item) {
                var currentindex = index + 1;
                object += '<tr>';
                object += '<td>' + currentindex + '</td>';
                object += '<td>' + item.name + '</td>';
                object += '<td>' + item.state + '</td>';
                object += '<td>' + item.city + '</td>';
                object += '<td>' + item.salary + '</td>';
                object += '<td>' + item.email + '</td>';
                object += '<td>' + item.phone + '</td>';
             
                //object += '<td><a href="#" class="btn btn-primary" onclick="Edit('+ item.id +')">Edit</a> || <a href="#" class="btn btn-danger" onclick="Delete(' + item.id + ')">Delete</a></td>';
                //object += '</tr>';
                object +=  '<td><a href="#" class="btn btn-primary" onclick="Edit(\'' + String(item.id) + '\')">Edit</a> || <a href="#" class="btn btn-danger" onclick="Delete(\'' + String(item.id) + '\')">Delete</a></td>';
                object += '</tr>';
                currentindex++;
            });
            $('#table_data').html(object);
        },
        error: function () {
            alert("Data can't get");
        }
    });
};

    $('#btnAddEmployee').click(function () {
        $('#EmployeeMadal').modal('show');
        $('#btnSubmit').show();
        $('#btnUpdate').hide();
        dataclose()
        datafield();

    })
function dataclose() {
    $('#close').click(function () {
        location.reload(true);
    })
}
function datafield() {
 
    var result = true;
    $('#Name').on('input', function () {
        var inputvalue = $(this).val();
        var alphebt = inputvalue.replace(/[^A-Za-z]/g,"");
        $(this).val(alphebt);
        result = true;

    });
   
    $('#State').on('input', function () {
        var inputvalue = $(this).val();
        var alphebt = inputvalue.replace(/[^A-Za-z]/g, "");
        $(this).val(alphebt);
        result = true;
    });
  
    $('#city').on('input', function () {
        var inputvalue = $(this).val();
        var alphebt = inputvalue.replace(/[^A-Za-z]/g, "");
        $(this).val(alphebt);
        result = true;
    });
   
    $('#Email').on('input', function () {
        var inputvalue = $(this).val();
     
        var alphebt = inputvalue.replace(/^[^\s@]+@[^\s@]+[^\s@]+\[^\s@]+$/, "");
        $(this).val(alphebt);
        result = true;
    });
   
    $('#Phone').on('input', function () {
        var inputvalue = $(this).val();
        var alphebet = inputvalue.replace(/\D/g, "");

        var trimmed = alphebet.slice(0, 10);
        $(this).val(trimmed);
        result = true;
    });

    
    $('#Salary').on('input', function () {
        var inputvalue = $(this).val();
        var alphebt = inputvalue.replace(/\D/g, "");
        $(this).val(alphebt);
        result = true;
    });
   
    return result;

   
}
$('#btnSubmit').click(function () {
    if (datafield() == false) {
        return false;
    }
    else {
        AddEmployeeData();
    }
})
$('#btnUpdate').click(function () {
    if (datafield() == false) {
        return false;
    }
    else {
        UpdateEmployee();
    }
})

function AddEmployeeData() {
    debugger
    var objData = {
     //   EmpID: $('#EmpID').val(),
        Name: $('#Name').val(),
        State: $('#State').val(),
        city: $('#city').val(),
        Salary: $('#Salary').val(),
        Email: $('#Email').val(),
        Phone: $('#Phone').val(),
        Password:$('#Password').val(),
     
    }
    $.ajax({
        url: '/Employe/AddEmployeeData',
        type: 'Post',
        data: objData,
        contentType: 'application/x-www-form-urlencoded;charset=utf-8;',
        dataType: 'json',
        success: function () {
            alert('Data Saved');
            ClearTextBox();
            ShowEmployeeData();
            HideModalPopUp();
        },
        error: function () {
            alert("Data can't Saved!");
        }

    });
}


function ClearTextBox() {
    $('#Name').val('');
        $('#State').val('');
      $('#city').val('');
        $('#Salary').val('');
    $('#EmpID').val('');
     $('#Email').val(''),
        $('#Phone').val('')
};

function HideModalPopUp() {
    $('#EmployeeMadal').modal('hide');
}

function Delete(id) {
    debugger;
    if (confirm('Are you sure, You want to delete this record?')) {
        $.ajax({
            url: '/Employe/Delete?id=' + id,
            success: function () {
                alert('Record Deleted!');
                ShowEmployeeData();
            },
            error: function () {
                alert("Data can't be deleted!");
            }
        })
    }
}

function Edit(id) {
    debugger
    $.ajax({
        url: '/Employe/Edit?id=' + id,
        type: 'Get',
        contentType: 'application/json;charset=utf-8',
        dataType: 'json',
        success: function (response) {
            $('#EmployeeMadal').modal('show');
            datafield();
            dataclose();
            $('#EmpId').val(response.id);
          //  console.log(response);
            $('#Name').val(response.name);
            $('#State').val(response.state);
            $('#city').val(response.city);
            $('#Salary').val(response.salary);
            $('#Email').val(response.email),
                $('#Phone').val(response.phone),
            $('#btnSubmit').hide();
            $('#btnUpdate').show();
            $('#employeeHeading').text('Update Record');
        },
        error: function () {
            alert('Data not found');
        }
    })
}

function UpdateEmployee() {
    debugger
    var objData = {
       // EmpID: $('#EmpID').val(),
        Name: $('#Name').val(),
        State: $('#State').val(),
        city: $('#city').val(),
        Salary: $('#Salary').val(),
        Email: $('#Email').val(),
        Phone: $('#Phone').val(),
    }
  
   
    $.ajax({
        url: '/Employe/Update',
        type: 'Post',
        data: objData, 
        contentType: 'application/x-www-form-urlencoded;charset=utf-8;',
        dataType: 'json',
        success: function () {
            alert('Data Updated');
            HideModalPopUp();
            ShowEmployeeData();
            ClearTextBox();
        },
        error: function () {
            alert("Data can't Saved!");
        }
    })
}

