﻿using ApplicationLayer.IServices;
using DataAcessLayer.Models;
using DataAcessVM.ViewModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;

namespace WebApplicationMVC.Controllers
{
    public class EmployeController : Controller
    {
        private readonly IEmployeService _service;
        private readonly UserManager<ApplicationUser> _userManager;

        public EmployeController(IEmployeService service, UserManager<ApplicationUser> userManager)
        {
            _service = service;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<JsonResult> Read()
        {
            var data = await _service.EmployeListAsync();
            return new JsonResult(data);
        }

        [HttpPost]
        public async Task<JsonResult> AddEmployeeData(EmployeModel employee)
        {
            var result = await _service.AddEmployee(employee);
            return new JsonResult(result);
        }

     /// <summary>
     /// //  [HttpPost]
     /// </summary>
     /// <param name="id"></param>
     /// <returns></returns>
        public async Task<JsonResult> Delete(string id)
        {
            var result = await _service.DeleteEmployeeAsync(id);
            return new JsonResult(result ? "Data Deleted" : "Failed to delete data");
        }

        [HttpGet]
        public async Task<JsonResult> Edit(string id)
        {
            var data = await _service.GetUserByIdAsync(id);
            return new JsonResult(data);
        }

        [HttpPost]
        public async Task<JsonResult> Update(EmployeModel obj)
        {
            var result = await _service.UpdateEmployeeAsync(obj);
            return new JsonResult(result ? "Record Updated!" : "Failed to update record");
        }
        [HttpGet]
        public IActionResult LoginData()
        
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> LoginData(LoginModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var result = await _service.LoginAsync(model.Email, model.Password);

            if (result)
            {
                return RedirectToAction("Index", "Employe"); // Redirect to home page upon successful login
            }

            ModelState.AddModelError(string.Empty, "Invalid username or password.");
            return View(model);
        }

















        //private readonly IEmployeService _repo;

        //public EmployeController(IEmployeService repo)
        //{
        //    _repo = repo;
        //}
        //public IActionResult Index()
        //{
        //    return View();
        //}


        //public JsonResult Read()
        //{
        //    var data = _repo.EmployeList();
        //   return  new JsonResult(data);
        //}



        //[HttpPost]
        //public JsonResult AddEmployeeData(EmployeModel employee)
        //{
        //    var data = _repo.AddEmployee(employee);


        //    return new JsonResult("Data is Saved");
        //}

        //public JsonResult Delete(int id)
        //{
        //    bool data = _repo.DeleteData(id);
        //    return new JsonResult("Data Deleted");
        //}
        //public JsonResult Edit(int id)
        //{
        //    EmployeModel data = new EmployeModel();
        //    data = _repo.GetUserById(id);
        //    return new JsonResult(data);
        //}
        //[HttpPost]

        //public JsonResult Update(EmployeModel obj)
        //{
        //    if (obj == null)
        //    {
        //        return null;
        //    }
        //    bool data = _repo.UpdateData(obj);
        //    return new JsonResult("Record Updated!");
        //}

        //public IActionResult LoginData()
        //{

        //    return View();
        //}

        //[HttpPost]

        //public async Task<IActionResult> LoginData(LoginModel obj)
        //{
        //    var result = await _repo.Login(obj);
        //    if (result != null)
        //    {
        //        return Ok(result);
        //    }

        //    return null;

        //}

        //[HttpPost("login")]
        //public async Task<IActionResult> Login([FromBody] LoginModel model)
        //{
        //    _logger.LogInformation("Getting Login details");
        //    var result = await _repository.Login(model);
        //    try
        //    {

        //        if (result == null)
        //            throw new ApplicationException("Getting errors while fetching customer details");
        //        if (result != null)
        //            return Ok(result);
        //        else
        //            return Unauthorized();

        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex.Message);
        //        return BadRequest("Internal server error");
        //    }
        //}
    }
}

















      
