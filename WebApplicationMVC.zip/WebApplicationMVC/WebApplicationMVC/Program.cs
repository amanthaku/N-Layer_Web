using ApplicationLayer.IServices;
using ApplicationLayer.Services;
using DataAcessLayer;
using DataAcessLayer.Models;
using Employe.Repository.IRepository;
using Employe.Repository.Repository;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<Db_Context>(Options =>
{
    Options.UseSqlServer(builder.Configuration.GetConnectionString("DatabaseConnection"));

});
builder.Services.AddIdentity<ApplicationUser, IdentityRole>()
                .AddEntityFrameworkStores<Db_Context>()
                .AddDefaultTokenProviders(); 
builder.Services.AddScoped<IEmployeService, EmployeServices>();
builder.Services.AddScoped<IEmployeRepository, EmployeRepository>();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Employe}/{action=LoginData}/{id?}");

app.Run();
