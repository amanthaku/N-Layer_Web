﻿using DataAcessVM.ViewModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationLayer.IServices
{
    public interface IEmployeService


    {


        public Task<List<EmployeModel>> EmployeListAsync();

        public Task<bool> AddEmployee(EmployeModel model);


        public Task<bool> DeleteEmployeeAsync(string id);

        public Task<EmployeModel> GetUserByIdAsync(string id);

        public Task<bool> UpdateEmployeeAsync(EmployeModel model);

        public Task<bool> LoginAsync(string Email, string password);
    }
}
        