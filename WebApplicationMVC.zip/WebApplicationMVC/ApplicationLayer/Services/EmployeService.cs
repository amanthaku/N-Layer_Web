﻿using ApplicationLayer.IServices;
using DataAcessLayer;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAcessVM.ViewModel;
using DataAcessLayer.Models;
using System.Numerics;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Employe.Repository.IRepository;

namespace ApplicationLayer.Services
{
    public class EmployeServices : IEmployeService
    {
        private readonly IEmployeRepository _context;

        public EmployeServices(IEmployeRepository context)
        {
            _context = context;
        }

        public async Task<List<EmployeModel>> EmployeListAsync()
        {
            return await _context.EmployeList();
        }

        public async Task<EmployeModel> GetUserByIdAsync(string id)
        {
            return await _context.GetUserById(id);
        }

        public async Task<bool> AddEmployee(EmployeModel model)
        {
            var data = await _context.AddEmployeeData(model);
            return true;
        }

        public async Task<bool> UpdateEmployeeAsync(EmployeModel model)
        {
           
            await _context.UpdateEmployee(model);
            return true;
        }

        public async Task<bool> DeleteEmployeeAsync(string id)
        {


            await _context.DeleteEmployee(id);
            return true;
        }

        public async Task<bool> LoginAsync(string Email, string password)
        {
            await _context.Login(Email, password);
            return true;
        }
    }
}

      
        //public async Task<bool> UpdateEmployeeAsync(EmployeModel model)
        //{
        //    var user = await _userManager.FindByEmailAsync(model.Email);
        //    if (user == null)
        //        return false;
        //    user.Name = model.Name;
        //    user.Salary = model.Salary;
        //    user.city = model.city;
        //    user.State = model.State;
        //    user.Email = model.Email;
        //    user.PhoneNumber = model.Phone;
        //    var result = await _userManager.UpdateAsync(user);
        //    return result.Succeeded;
        //}
        //public async Task<bool> LoginAsync(string Email, string password)
        //{
        //    var result = await _signInManager.PasswordSignInAsync(Email, password, false, lockoutOnFailure: false);
        //    return result.Succeeded;
        //}



        //public class EmployeService : IEmployeService
        //{

        //    private readonly Db_Context _repo;


            //public EmployeService(Db_Context repo)
            //{
            //    _repo = repo;
            //}

            //public List<EmployeModel> EmployeList()
            //{

            //    var data = _repo.ApplicationUsers.ToList();
            //    List<EmployeModel> listData = new();
            //    foreach (var i in data)
            //    {
            //        var abc = new EmployeModel()
            //        {

            //            //Id = i.Id,
            //            Name = i.Name,
            //            Salary = i.Salary,
            //            city = i.city,
            //            State = i.State,
            //            Email = i.Email,
            //            Phone = i.Phone,


            //        };
            //        listData.Add(abc);
            //    }
            //    return listData;
            //}
            ////public async Task<IEnumerable<ApplicationUser>> GetAllUsersAsync()
            ////{
            ////    return await _userManager.Users.ToListAsync();
            ////}
            //public bool AddEmployee()
            //{
            //    var data = _repo.ApplicationUsers.ToList();
            //    return true;
            //}
            //[HttpPost]
            //public bool AddEmployee(EmployeModel data)
            //{
            //    if (data == null)
            //    {
            //        return false;
            //    }
            //    var abc = new ApplicationUser()
            //    {
            //        //  EmpID = data.EmpID,
            //        Name = data.Name,
            //        Salary = data.Salary,
            //        city = data.city,
            //        State = data.State,
            //        Email = data.Email,
            //        Phone = data.Phone,

            //    };

            //    _repo.ApplicationUsers.Add(abc);

            //    _repo.SaveChanges();
            //    return true;
            //}

            //public async Task<string> Login(LoginModel model)
            //{
            //    var user = await _userManager.FindByEmailAsync(model.Email);
            //    if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
            //    {




            //    }


            //    return null;
            //}

            //public bool DeleteData(int id)
            //{
            //    //  var data = _repo.ApplicationUsers.Where(x => x.EmpID == id).First();
            //    //   if (data == null)
            //    {
            //        return false;
            //    }
            //    //   _repo.ApplicationUsers.Remove(data);
            //    _repo.SaveChanges();
            //    return true;
            //}
            //// public async Task<string> DeleteData(string Id)
            ////public async Task<bool> DeleteData(string Id) { 
            ////{
            ////    var user = await _userManager.Users.FirstOrDefaultAsync(x => x.Id == Id);

            ////            IdentityResult result = await _userManager.DeleteAsync(user);

            ////            if (result.Succeeded)
            ////            {
            ////            return true;
            ////            }
            ////        return false;
            ////}

            //public EmployeModel GetUserById(int id)
            //{
            //    ApplicationUser data = new ApplicationUser();
            //    //  data = _repo.ApplicationUsers.Where(x => x.EmpID == id).First();
            //    EmployeModel store = new EmployeModel();

            //    //store.EmpID = data.EmpID;
            //    store.Name = data.Name;
            //    store.Salary = data.Salary;
            //    store.city = data.city;
            //    store.State = data.State;
            //    store.Email = data.Email;
            //    store.Phone = data.Phone;


            //    return store;





            //}

            //public bool UpdateData(EmployeModel obj)
            //{
            //    if (obj == null)
            //    {
            //        return false;
            //    }
            //    ApplicationUser data = new ApplicationUser();
            //    // data = _repo.ApplicationUsers.Where(x => x.Id == obj.EmpID).First();

            //    //  data.EmpID = obj.EmpID;
            //    data.Name = obj.Name;
            //    data.Salary = obj.Salary;
            //    data.city = obj.city;
            //    data.State = obj.State;
            //    data.Email = obj.Email;
            //    data.Phone = obj.Phone;



            //    _repo.ApplicationUsers.Update(data);

            //    _repo.SaveChanges();

            //    return true;
            //}


        //}
//}









